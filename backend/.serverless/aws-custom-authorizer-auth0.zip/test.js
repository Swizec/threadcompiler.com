const secrets = require('./secrets.json')


const twitterAPI = require('node-twitter-api')
const twitter = new twitterAPI({
    consumerKey: secrets.TWITTER_CONSUMER_KEY,
    consumerSecret: secrets.TWITTER_CONSUMER_SECRET,
})

async function tweet(text) {
    return new Promise((resolve, reject) => {
        twitter.statuses(
            'update', {
                status: text,
            },
            '15353121-6RpAhdCJdV1CfxKOAHavBlR3zPkhkh1o61FnIne2a',
            'Rw1CCkzqbdNRk8D9sjB8rJ7V9muvOA37ryludMMve85Vk',
            (err, data, response) => {
                if (err) {
                    reject(err)
                } else {
                    resolve(data)
                }
            }
        )
    })
}

async function runTest() {
    const result = await tweet("This is a test.")
    console.log(result)
}

runTest()